import sys
sys.path.insert(0,'..')

from ftx import FtxWebsocketClient
import time
import json
from datetime import datetime
from getpass import getpass
import threading
# pip install mysql-connector-python

#write_ctr += 0
data=[]
ws = FtxWebsocketClient()

while True:
    
    #cur_data = ws.wait_for_orderbook_update(market='BTC/USDT',timeout=10.0)
    #cur_data=ws.get_trades(market='BTC/USDT')
    #cur_data=ws.get_orderbook(market='ETH/USDT')
    #cur_data=ws.get_orders()
    #cur_data=str(ws.get_orderbook_timestamp(market='BTC/USDT'))
    #print('asks:',cur_data['asks'][0:5])
    #for i in cur_data:
        #print(i)
        #data.append(i)
    cur_data=ws.get_ticker(market='BTC/USDT')
    
    print(cur_data)
    '''
    for data in cur_data:
        for d in data:
            price=float(d['price'])
            size = d["size"]
            id = d["id"]
            trade_time = d["time"].split(".")[0].replace(":", ".").replace("T", " ")
            isBuyer = "False" if (d["side"]=="buy") else "True"
    print(price,size,id,trade_time,isBuyer)        
    #print(datetime.now(),cur_data['asks'][0],cur_data['bids'][0])
   '''
    time.sleep(3)

