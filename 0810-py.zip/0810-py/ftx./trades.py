from os import curdir
from ftx import FtxWebsocketClient
import time
import json
from datetime import datetime
from getpass import getpass

from mysql.connector import connect, Error

with open('../config.json') as json_file:
    config = json.load(json_file)

try:
    mydb = connect(
        host=config["db_host"],
        user=config["db_user"],
        password=config["db_pwd"],
        database=config["database"]["ftx_socket"]
    )
except Error as e:
    print(e)
cur = mydb.cursor()

ws = FtxWebsocketClient()
while True:
    cur_data = ws.get_trades(market='BTC/USDT')
    for data in cur_data:
        for d in data: ## in same list if the trade gets same timestamp
            price = float(d["price"])
            size = d["size"]
            id = d["id"]
            trade_time = d["time"].split(".")[0].replace(":", ".").replace("T", " ")
            isBuyer = "False" if (d["side"]=="buy") else "True"
            #sql = "INSERT INTO trade (time, isBuyerMaker, price, quantity, tradeId) VALUES ('{trade_time}', '{isBuyer}', '{price}', '{size}', '{id}');".format(trade_time=trade_time, isBuyer=isBuyer, price=price, size=size, id=id)
            sql = "INSERT INTO trade (time, isBuyerMaker, price, quantity, id) VALUES ('{trade_time}', '{isBuyer}', '{price}', '{size}', '{id}');".format(trade_time=trade_time, isBuyer=isBuyer, price=price, size=size, id=id)
            
            try:
                cur.execute(sql)
                mydb.commit()
            except:
                # 避免存入同比資料兩次以上，所以有使用這個 unique_id 來判斷是否已經存在資料庫了
                print("Same id: "+str(id))
    time.sleep(10)
