import sys
sys.path.insert(0,'..')

from ftx import FtxWebsocketClient
import time
import json
from datetime import datetime
from getpass import getpass
# pip install mysql-connector-python
from csv_process import to_csv, write_interval, get_lists, init_interval

with open('../config.json') as json_file:
    config = json.load(json_file)

write_ctr = 1

csv_bids = []
csv_asks = []
csv_since = []
crawl_first_data = True

def save_time(t):
    global csv_since
    global crawl_first_data
    if(crawl_first_data):
        print("... Crawl data ...")
        crawl_first_data = False
    print("  "+str(t))
    csv_since.append(t)

def save_data(cur_data, key):
    global csv_asks
    global csv_bids
    if(key == "asks"):
        csv_asks.append(cur_data)
    else:
        csv_bids.append(cur_data)

ws = FtxWebsocketClient()
init_interval()
while True:
    #now = datetime.now() # current date and time
    #since = now.strftime("%Y-%d-%m %H.%M.%S")
    #strtime = now.strftime("%Y-%d-%m %H.%M.%S")
    #struct_time = time.strptime(strtime, "%Y-%m-%d %H.%M.%S")
    t = time.time()
    since = (str(int(t*10))+'97')
    #since = int(time.mktime(struct_time))
    

    
    cur_data = ws.get_orderbook(market='BTC/USDT')
    if write_ctr == 1:
        save_time(since)
        save_data(cur_data["asks"], "asks")
        save_data(cur_data["bids"], "bids")
    #if(write_ctr == 10):
        tmp_ask = csv_asks.copy()
        tmp_bids = csv_bids.copy()
        tmp_times = csv_since.copy()
        write_interval(tmp_ask, tmp_bids, tmp_times)
        csv_asks.clear()
        csv_bids.clear()
        csv_since.clear()
        write_ctr = 0
        crawl_first_data = True
    write_ctr += 1
    time.sleep(0.19)
