import sys
sys.path.insert(0,'..')

from ftx import FtxWebsocketClient
import time
import json
from datetime import datetime
from getpass import getpass
import threading
# pip install mysql-connector-python
from mysql.connector import connect, Error
from csv_process import to_csv, write, get_lists, init

with open('../config.json') as json_file:
    config = json.load(json_file)

old_bids = []
old_asks = []

write_ctr = 1

csv_bids = []
csv_asks = []
csv_since = []
crawl_first_data = True

def save_time(t):
    global csv_since
    global crawl_first_data
    if(crawl_first_data):
        print("... Crawl data ...")
        crawl_first_data = False
    print("  "+str(t))
    csv_since.append(t)

def save_data(cur_data, key):
    global csv_asks
    global csv_bids
    if(key == "asks"):
        csv_asks.append(cur_data)
    else:
        csv_bids.append(cur_data)

'''
def insert_new_data(cur_data, old_data, key, since):
    try:
        mydb = connect(
            host=config["db_host"],
            user=config["db_user"],
            password=config["db_pwd"],
            database=config["database"]["ftx_socket"]
        )
    except Error as e:
        print(e)
    cur = mydb.cursor()
    for data in cur_data:
        if data in old_data:
            continue
        else:
            (price, size) = data
            find_exist = "SELECT id FROM orderbook_{0} WHERE price='{1}' AND quantity='{2}';".format(key, price, size)
            cur.execute(find_exist)
            result = cur.fetchone()
            if (not result):
                sql = "INSERT INTO orderbook_{0} (price, quantity, time) VALUES ('{1}', '{2}', '{3}' )".format(key, price, size, since)
                cur.execute(sql)
    mydb.commit()
    cur.close()
    mydb.close()
    '''

pools = []
ws = FtxWebsocketClient()
init()
while True:
    #now = datetime.now() # current date and time
    #since = now.strftime("%Y-%d-%m %H.%M.%S")
    #strtime = now.strftime("%Y-%d-%m %H.%M.%S")
    #struct_time = time.strptime(strtime, "%Y-%m-%d %H.%M.%S")
    t = time.time()
    since = (str(int(t))+'000')
    

    cur_data = ws.get_orderbook(market='BTC/USDT')
    
    #t = threading.Thread(target = insert_new_data,  args=[cur_data["bids"], old_bids, "bids", since])
    #t2 = threading.Thread(target = insert_new_data,  args=[cur_data["asks"], old_asks, "asks", since])
    #t.start()
    #t2.start()
    #pools.append((t, t2))
    # insert_new_data(cur_data["bids"], old_bids, "bids", since)
    # insert_new_data(cur_data["asks"], old_asks, "asks", since)
    save_time(since)
    save_data(cur_data["asks"][0:10], "asks")
    save_data(cur_data["bids"][0:10], "bids")
    if(write_ctr == 1):
        tmp_ask = csv_asks.copy()
        tmp_bids = csv_bids.copy()
        tmp_times = csv_since.copy()
        write(tmp_ask, tmp_bids, tmp_times)
        csv_asks.clear()
        csv_bids.clear()
        csv_since.clear()
        write_ctr = 0
        crawl_first_data = True
        for (t, t2) in pools:
            t.join()
            t2.join()
        pools.clear()

    old_bids = cur_data["bids"].copy()
    old_asks = cur_data["asks"].copy()
    write_ctr += 1
    time.sleep(1)
